<?php

namespace App\Modules\CaseManagement\Http\Controllers;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CaseReportController extends Controller
{
    public function printAllcaseform(Request $request)
    {
        try{
          $form_id=$request->input('form_id');
          $case_id=$request->input('case_id');
          $case_girl_id=$request->input('case_girl_id');
          $year=$request->input('year');
          $is_mainReport=$request->input('is_mainReport');
          $report='';
          if(isset($form_id) && $form_id==1){
               $report = generateJasperReport('casemanagement/case_intake', 'intake_form_' . time(), 'pdf');
          }else if(isset($form_id) && $form_id==2){
              $report = generateJasperReport('casemanagement/assessment_careplan', 'assessment_careplan_form_' . time(), 'pdf');
          }else if(isset($form_id) && $form_id==3){
              $report = generateJasperReport('casemanagement/referral_form', 'referral_form_' . time(), 'pdf');
          }else if(isset($form_id) && $form_id==4){
              $report = generateJasperReport('casemanagement/caseReview_form', 'case_review_form_' . time(), 'pdf');
          }else if(isset($form_id) && $form_id==5){
              $report = generateJasperReport('casemanagement/caseLog_sheet', '/case_Log_sheet_' . time(), 'pdf');
          }else if(isset($form_id) && $form_id==6){
              $report = generateJasperReport('casemanagement/case_closure_form', 'case_closure_form_' . time(), 'pdf');
          }else if(isset($case_id) && $is_mainReport!=1){
            echo "wrong";
             $params = array(
              'case_id'=>$case_id,
            );
           $report = generateJasperReport('casemanagement/preloaded_referral_form', 'preloaded_referral_form_' . time(), 'pdf', $params);
          }else{
            //Print combined report
            $params = array(
              'case_id'=>$case_id,
              'case_girl_id'=>$case_girl_id,
              'year'=>$year
            );
            $report = generateJasperReport('casemanagement/MainCaseManagementForms', 'preloaded_referral_form_' . time(), 'pdf', $params);
          }
        }catch (\Exception $exception) {
            $res = array(
                'success' => false,
                'message' => $exception->getMessage()
            );
            print_r($res);
        } catch (\Throwable $throwable) {
            $res = array(
                'success' => false,
                'message' => $throwable->getMessage()
            );
            print_r($res);
        }
        return $report;
    }
}
